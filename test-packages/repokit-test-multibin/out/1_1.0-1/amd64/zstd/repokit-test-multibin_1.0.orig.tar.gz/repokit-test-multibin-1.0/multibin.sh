#!/bin/sh
echo "repokit-test-multibin"
