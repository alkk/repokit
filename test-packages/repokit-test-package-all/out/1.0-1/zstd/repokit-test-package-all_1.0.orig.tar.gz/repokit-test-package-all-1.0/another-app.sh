#!/bin/sh

date
echo Test app - all
