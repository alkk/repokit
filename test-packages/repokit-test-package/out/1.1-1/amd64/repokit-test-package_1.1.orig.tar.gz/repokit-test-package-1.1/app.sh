#!/bin/sh

date
echo Test app v1.1
